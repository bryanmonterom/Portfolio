﻿namespace Portfolio.Models
{
    public class Badges
    {
        public string Badge { get; set; }
        public string Issuer { get; set; }
        public string Img { get; set; }


    }
}
