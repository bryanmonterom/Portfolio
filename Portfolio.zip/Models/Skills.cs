namespace Portfolio.Models
{
    public class Skills
    {
        public string Name { get; set; }
        public string Type { get; set; }
    }
}